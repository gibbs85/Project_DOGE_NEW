using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public static int Money = 150;

    public int GetMoney()
    {
        return Money;
    }
}
