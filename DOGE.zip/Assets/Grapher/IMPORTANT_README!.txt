[!!! OLDER VERSIONS OF UNITY ONLY (pre 2017) !!!]

Due to the Unity Asset Store folder structure policy for the assets, folder "Grapher" needs to be manually moved to "Editor" folder so the structure is as following:

Assets > Editor > Grapher

This is needed for Grapher to work properly.
If "Editor" folder does not exist in your project you will need to make a new folder.
